import java.util.Comparator;


public class ComparatorDeadline implements Comparator<task>{

	@Override
	public int compare(task o1, task o2) {
		// TODO Auto-generated method stub
		  if (o1.RealDeadline > o2.RealDeadline) {
		   return 1;
		  }
		  else if (o1.RealDeadline == o2.RealDeadline) {
		   if (o1.Priority < o2.Priority) {
		    return 1;
		   }
		  }
		  return -1;
	}
	
}
