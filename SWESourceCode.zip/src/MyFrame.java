import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Scrollbar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import java.awt.Point;
import java.util.Random;
import java.awt.ComponentOrientation;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyFrame extends JFrame{
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField val_Name;
	public int Num_PeriodicInsert=0;
	public int Num_AperiodicInsert=0;
	static int firstTime;
	static int lastTime;
	public MyFrame(){
		setTitle("Input setting");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		  String[] colName = {"�̸�","�������","����ð�","���۽ð�","�ֱ�","�켱����"}; //�÷��̸�
		  Object[][] rowData={};
		//JTable�� ��ü�� �����Ҷ� colName[],rowData[][]�� ����� ���̺��� ������ �� ������
		//���� ����ϸ� ���̺��� �߰�, ����, �������� �ϴµ� �����ϴ�
		DefaultTableModel model = new DefaultTableModel(rowData,colName){
	         public boolean isCellEditable(int i, int c){
	             return false;
	            }
	           };//�𵨻���
		JPanel panel = new JPanel();
		
		JLabel ModeSelection = new JLabel("Mode Selection");
		ModeSelection.setBounds(93, 21, 99, 28);
		JLabel Deadline = new JLabel("Deadline");
		Deadline.setBounds(208, 134, 49, 15);
		
		JButton Delete = new JButton("Delete Selected task");
		Delete.setBounds(741, 303, 191, 23);
		JButton Add = new JButton("Add");
		Add.setBounds(783, 164, 129, 22);
		panel.setLayout(null);
		
		panel.add(ModeSelection);
		panel.add(Deadline);
		panel.add(Add);
		panel.add(Delete);
		panel.setSize(980,498);
		
		JLabel lblProgram = new JLabel("Priority");
		lblProgram.setBounds(703, 134, 57, 15);
		panel.add(lblProgram);
		
		JLabel Showing_Num = new JLabel("�Է��� Task�� ���� : " + model.getRowCount());
		Showing_Num.setBounds(761, 232, 171, 15);
		panel.add(Showing_Num);
		
		JLabel lblPriority = new JLabel("Performance Time");
		lblPriority.setBounds(307, 134, 105, 15);
		panel.add(lblPriority);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(73, 134, 57, 15);
		panel.add(lblName);
		
		JRadioButton BtnEDF = new JRadioButton("EDF Mode");
		buttonGroup.add(BtnEDF);
		BtnEDF.setBounds(505, 24, 121, 23);
		panel.add(BtnEDF);
		
		JRadioButton BtnRM = new JRadioButton("RM Mdoe");
		BtnRM.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		buttonGroup.add(BtnRM);
		BtnRM.setSelected(true);
		BtnRM.setBounds(288, 24, 121, 23);
		panel.add(BtnRM);
		
		JRadioButton BtnPriority = new JRadioButton("Priority Mode");
		buttonGroup.add(BtnPriority);
		BtnPriority.setBounds(722, 24, 121, 23);
		panel.add(BtnPriority);
		
		JLabel lblStartTime = new JLabel("Start Time");
		lblStartTime.setBounds(457, 134, 80, 15);
		panel.add(lblStartTime);
		
		JLabel lblPeriodic = new JLabel("Periodic");
		lblPeriodic.setBounds(596, 134, 57, 15);
		panel.add(lblPeriodic);
		JTable table = new JTable(model);
		table.setUpdateSelectionOnSort(false);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setEnabled(false);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setSize(708, 225);
		scrollPane.setPreferredSize(new Dimension(300, 200));
		scrollPane.setLocation(new Point(20, 225));
		
		table.getTableHeader().setReorderingAllowed(false); //���̺� �÷� ���� ���� ����
		//table.setBounds(36, 218, 709, 229);
		panel.add(scrollPane);
		
		JButton btnNext = new JButton("SIMULATION START");
		
		btnNext.setBounds(741, 402, 191, 50);
		panel.add(btnNext);
		
		JSpinner val_StartTime = new JSpinner();
		val_StartTime.setModel(new SpinnerNumberModel(30, 1, 1000, 1));
		val_StartTime.setBounds(466, 164, 50, 22);
		panel.add(val_StartTime);
		
		
		
		JSpinner val_Deadline = new JSpinner();
		val_Deadline.setModel(new SpinnerNumberModel(30, 1, 1000, 1));
		val_Deadline.setBounds(208, 164, 50, 22);
		panel.add(val_Deadline);
		
		JSpinner val_PerformTime = new JSpinner();
		val_PerformTime.setModel(new SpinnerNumberModel(5, 1, 1000, 1));
		val_PerformTime.setBounds(334, 164, 50, 22);
		panel.add(val_PerformTime);
		
		JSpinner val_Periodic = new JSpinner();
		val_Periodic.setModel(new SpinnerNumberModel(50, 1, 1000, 1));
		val_Periodic.setBounds(610, 164, 50, 22);
		panel.add(val_Periodic);
		
		JSpinner val_Priority = new JSpinner();
		val_Priority.setModel(new SpinnerNumberModel(1, 1, 1000, 1));
		val_Priority.setBounds(699, 164, 50, 22);
		panel.add(val_Priority);
		
		val_Name = new JTextField();
		val_Name.setHorizontalAlignment(SwingConstants.LEFT);
		val_Name.setText("Task \uC774\uB984 \uC785\uB825");
		val_Name.setBounds(36, 164, 129, 22);
		panel.add(val_Name);
		val_Name.setColumns(10);
		
		JLabel lblRandomInput = new JLabel("Periodic Random input");
		lblRandomInput.setBounds(52, 74, 161, 28);
		panel.add(lblRandomInput);
		
		JSpinner PeriodicRandom = new JSpinner();
		PeriodicRandom.setModel(new SpinnerNumberModel(0, 0, 99, 1));
		PeriodicRandom.setBounds(197, 77, 64, 22);
		panel.add(PeriodicRandom);
		
		JSpinner NonPerodicRandom = new JSpinner();
		NonPerodicRandom.setModel(new SpinnerNumberModel(0, 0, 99, 1));
		NonPerodicRandom.setBounds(623, 78, 64, 22);
		panel.add(NonPerodicRandom);
		
		JLabel lblAperiodicRandomInput = new JLabel("Aperiodic Random input");
		lblAperiodicRandomInput.setBounds(466, 74, 192, 28);
		panel.add(lblAperiodicRandomInput);
		
		JButton PeriodicRandomInsertBtn = new JButton("Insert");
		PeriodicRandomInsertBtn.setBounds(283, 77, 97, 23);
		panel.add(PeriodicRandomInsertBtn);
		
		
		JRadioButton Check_Periodic = new JRadioButton();
		Check_Periodic.setSelected(true);
		Check_Periodic.setBounds(584, 164, 29, 23);
		panel.add(Check_Periodic);
		
		JButton btnAperiodicTaskDelete = new JButton("Delete Aperiodic task");
		JButton btnPeriodicTaskDelete = new JButton("Delete Periodic task");
		btnAperiodicTaskDelete.setBounds(741, 369, 191, 23);
		panel.add(btnAperiodicTaskDelete);
		
		JButton AperiodicRandomInsertBtn = new JButton("Insert");
		
				getContentPane().add(panel);

				
				
				
				btnPeriodicTaskDelete.setBounds(741, 336, 191, 23);
				panel.add(btnPeriodicTaskDelete);
				
				JLabel lblTime = new JLabel("TIME :       0");
				lblTime.setBounds(740, 276, 92, 15);
				panel.add(lblTime);
				
				JLabel label = new JLabel("~");
				label.setBounds(832, 276, 29, 15);
				panel.add(label);
				
				JSpinner Finalsp = new JSpinner();
				Finalsp.setModel(new SpinnerNumberModel(100, 1, 99999, 1));
				Finalsp.setBounds(865, 271, 49, 22);
				panel.add(Finalsp);
				
				AperiodicRandomInsertBtn.setBounds(714, 77, 97, 23);
				panel.add(AperiodicRandomInsertBtn);
				
				
				
				
				
				
				// btn �̺�Ʈ ����
				Add.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						  Object[] add={"�ŵ�����",1,2,3,4,5};//�߰��� �� ����
						  add[0]=val_Name.getText();
						  add[1]=val_Deadline.getValue();
						  add[2]=val_PerformTime.getValue();
						  add[3]=val_StartTime.getValue();
						  if(Check_Periodic.isSelected())
							  add[4]=val_Periodic.getValue();
						  else
							  add[4]=0;
						  add[5]=val_Priority.getValue();
						  model.addRow(add);//���̺��� ������ �߰�., �𵨿� �߰����ָ� ���̺��� �ڵ����� �߰��ȴ�.
						  Showing_Num.setText("�Է��� Task�� ���� : " + model.getRowCount());
					}
				});
				
				PeriodicRandomInsertBtn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						  Random rand = new Random(System.currentTimeMillis());
						  //�ֱ� Task
						  
						  Object[] add={"�ŵ�����",1,2,3,4,5};//�߰��� �� ����
						  int num_insert = (int) PeriodicRandom.getValue();
						  int i=0;
						  while(i<num_insert){
						  add[0]="PeriodicInsert"+String.format("%03d", Num_PeriodicInsert);
						  add[4]=rand.nextInt((int)Finalsp.getValue())+30;//�ֱ�
						  add[1]=rand.nextInt((int)add[4])/2+15;//�������
						  add[2]=rand.nextInt((int)add[1])/2+1;//����ð�
						  add[3]=rand.nextInt((int)Finalsp.getValue());//���۽ð�
						  
						  add[5]=rand.nextInt((int)Finalsp.getValue())/10+30;//�켱����
						  model.addRow(add);
						  i++;
						  Num_PeriodicInsert++;
						  }
						  
						 // Num_Non_PeriodicInsert;
						  //���ֱ� Task
						  Showing_Num.setText("�Է��� Task�� ���� : " + model.getRowCount());
					}
				});
				
				AperiodicRandomInsertBtn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						  Random rand = new Random(System.currentTimeMillis());
						  //�ֱ� Task
						  
						  Object[] add={"�̸�",1,2,3,4,5};//�߰��� �� ����
						  int num_insert = (int) NonPerodicRandom.getValue();
						  int i=0;
						  while(i<num_insert){
						  add[0]="AperiodicInsert"+String.format("%03d",Num_AperiodicInsert);
						  add[1]=rand.nextInt((int)Finalsp.getValue())*2/3+15;
						  add[2]=rand.nextInt((int)add[1])/2+1;
						  add[3]=rand.nextInt((int)Finalsp.getValue());
						  add[4]=0;
						  add[5]=rand.nextInt((int)Finalsp.getValue())/10+30;
						  model.addRow(add);
						  i++;
						  Num_AperiodicInsert++;
						  }
						  Showing_Num.setText("�Է��� Task�� ���� : " + model.getRowCount());
					}
				});
				
				Delete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						while(table.getSelectedRow()>=0)
								model.removeRow(table.getSelectedRow());
						Showing_Num.setText("�Է��� Task�� ���� : " + model.getRowCount());
					}
					});
				

				btnAperiodicTaskDelete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						for(int i=0;i<model.getRowCount();i++)
							if((int)model.getValueAt(i, 4)==0){
								model.removeRow(i);
								i--;
							}
						Showing_Num.setText("�Է��� Task�� ���� : " + model.getRowCount());
					}
				});


				btnPeriodicTaskDelete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						for(int i=0;i<model.getRowCount();i++)
							if((int)model.getValueAt(i, 4)!=0){
								model.removeRow(i);
								i--;
							}
						Showing_Num.setText("�Է��� Task�� ���� : " + model.getRowCount());
					}
				});
				
				btnNext.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0){
						JTable temp = new JTable(model);
						
						
						int ModeNum=0;
						if(BtnRM.isSelected())
							ModeNum=1;
						else if(BtnEDF.isSelected())
							ModeNum=2;
						else if(BtnPriority.isSelected())
							ModeNum=3;
						lastTime = (int)Finalsp.getValue();
						CheckErrorInput MainSimulation = new CheckErrorInput(model,ModeNum);
					}
				});
				
				
				setLocation(500,150);
				setSize(960,529); //������ ����� ����.
				
				
				
				//MenuBar ����.
				JMenuBar menuBar = new JMenuBar();
				setJMenuBar(menuBar);
				
				JMenu mnHelp = new JMenu("Help");
				menuBar.add(mnHelp);
				
				JMenuItem mntmNewMenuItem_2 = new JMenuItem("\uC774\uC6A9\uBC29\uBC95");
				mntmNewMenuItem_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Help aa = new Help();
						
					}
				});
				mnHelp.add(mntmNewMenuItem_2);
		
				setVisible(true); 
	}
}