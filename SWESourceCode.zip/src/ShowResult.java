import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Scrollbar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import java.awt.Point;
import java.util.Random;
import java.awt.ComponentOrientation;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;


public class ShowResult extends JFrame{
	
	public ShowResult(task[] taskData){
		super("��� ���");
		
		setLocation(500, 300);
		setSize(500, 300);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		int NumAperiodic = 0;
		int NumPeriodic = 0;
		int NumProcess = 0;
		int NuminCPU = 0;
		int NumEndTask = 0;
		int NumEndProcess = 0;
		int NumAbnormalEndProcess = 0;
		int NumAbnormalEndTask = 0;
		int AverageResponseTime = 0;
		int WorstResponseTime = 0;
		
		int ResponseNum=0;

		
		for(int i=0;i<taskData.length;i++){
			if(taskData[i].Periodic>0)
				NumPeriodic++;
			else
				NumAperiodic++;
			
			NumProcess+=taskData[i].Time_inCPUStart.size();
			
			if(taskData[i].isinCPU)
				NuminCPU++;

			if(taskData[i].Time_inCPUEnd.size()>0){
			NumEndProcess = NumEndProcess + taskData[i].Time_inCPUEnd.size();
			NumEndTask++;
			}
			if(taskData[i].Time_OverDeadline.size()>0){
			NumAbnormalEndProcess += taskData[i].Time_OverDeadline.size();
			NumAbnormalEndTask++;
			}
			
			if(taskData[i].WorstResponseTime>WorstResponseTime)
				WorstResponseTime=taskData[i].WorstResponseTime;
			AverageResponseTime+=taskData[i].ResponseTime;
			ResponseNum+=taskData[i].ResponseNum;
			

		}
		if(ResponseNum>0)
			AverageResponseTime=AverageResponseTime/ResponseNum;
			
		JLabel TotalTask = new JLabel("\uCD1D Task \uC218 (\uC8FC\uAE30/\uBE44\uC8FC\uAE30) : " + taskData.length + " (" + NumPeriodic +" / "+ NumAperiodic + ")");
		TotalTask.setBounds(27, 24, 298, 15);
		panel.add(TotalTask);
		
		JLabel TotalProcess = new JLabel("\uC2E4\uD589\uB41C Process \uC218 : " + NumProcess);
		TotalProcess.setBounds(27, 63, 279, 15);
		panel.add(TotalProcess);
		
		JLabel InCPU = new JLabel("\uC885\uB8CC\uC2DC\uC5D0 \uC2E4\uD589/\uB300\uAE30 \uC911\uC778 Task \uC218 : " + NuminCPU);
		InCPU.setBounds(27, 102, 373, 15);
		panel.add(InCPU);
		
		JLabel NormalEnd = new JLabel("\uC815\uC0C1\uC801\uC73C\uB85C \uC885\uB8CC\uB41C Task / Process \uC218 : " + NumEndTask + " / " + NumEndProcess);
		NormalEnd.setBounds(27, 141, 315, 15);
		panel.add(NormalEnd);
		
		JLabel ResponseTime = new JLabel("\uD3C9\uADE0 / \uCD5C\uC545 \uC751\uB2F5\uC2DC\uAC04 : " + AverageResponseTime + " / " + WorstResponseTime);
		ResponseTime.setBounds(27, 180, 298, 15);
		panel.add(ResponseTime);
		
		
		JLabel OverDeadline = new JLabel("Deadline\uC744 \uCD08\uACFC\uD55C Task\uC758 \uC218 / Process\uC758 \uC218" + NumAbnormalEndTask + " / " + NumAbnormalEndProcess);
		OverDeadline.setBounds(27, 219, 315, 15);
		panel.add(OverDeadline);
		
		
		
		
		
		
		setVisible(true);
	}

}
