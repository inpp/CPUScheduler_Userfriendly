import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Zoomable;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import java.awt.Point;
import java.util.Random;
import java.awt.ComponentOrientation;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.border.LineBorder;

public class GanttChart extends JFrame {
	

    public GanttChart(task[] taskData) {
    	
        super("Simulation ��� ���â");
        final IntervalCategoryDataset dataset = createSampleDataset(taskData);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        // create the chart...
        final JFreeChart chart = ChartFactory.createGanttChart(
            "Simulation Result",  // chart title
            "Task",              // domain axis label
            "Time",              // range axis label
            dataset,             // data
            true,                // include legend
            true,                // tooltips
            false                // urls
        );
        
        final CategoryPlot plot = (CategoryPlot) chart.getPlot();
        DateAxis range = new DateAxis("Time");
        range.setDateFormatOverride(new SimpleDateFormat("s,SSS"));
        range.setMaximumDate(new Date(MyFrame.lastTime));
        range.setMinimumDate(new Date(0));
        plot.setRangeAxis(range);
       
        
        CategoryItemRenderer renderer = plot.getRenderer();
        
        renderer.setSeriesPaint(0, Color.darkGray);


        // add the chart to a panel...
        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(1500, 700));
        
        chartPanel.setRangeZoomable(true); 
        chartPanel.setDomainZoomable(true);
        //chartPanel.setMouseZoomable(true);
        setContentPane(chartPanel);
        

        
        setLocation(300,0);
        setSize(1500, 1000);
		setVisible(true);
		
        ShowResult sr = new ShowResult(taskData);
    }
    
    private IntervalCategoryDataset createSampleDataset(task[] taskData) {

        final TaskSeries s1 = new TaskSeries("GRAY : int Queue       GREEN : Execute       RED : Abnormal Termination(Exceed Deadline) ");
        int length=taskData.length;
        Task[] MainTask = new Task[length];
        Task[] SubTask = new Task[MyFrame.lastTime*1000];
        int Num_Subtask = 0;
        for(int i=0;i<length;i++){
        	//�켱 ����
        	MainTask[i] = new Task(taskData[i].name, new SimpleTimePeriod(0, MyFrame.lastTime+1));        	
        	//CPU���� ���+�����ϴ� �ð��� �־���
        	for(int time=0;time<taskData[i].Time_inCPUEnd.size();time++){
        		SubTask[Num_Subtask] = new Task("CPU���", new SimpleTimePeriod(taskData[i].Time_inCPUStart.get(time), taskData[i].Time_inCPUEnd.get(time)));
        		MainTask[i].addSubtask(SubTask[Num_Subtask]);
        		Num_Subtask++;
        	}
        	if(taskData[i].Time_inCPUEnd.size()<taskData[i].Time_inCPUStart.size()){
        		SubTask[Num_Subtask] = new Task("CPU���", new SimpleTimePeriod(taskData[i].Time_inCPUStart.get(taskData[i].Time_inCPUStart.size()-1),MyFrame.lastTime+1));
        		MainTask[i].addSubtask(SubTask[Num_Subtask]);
        		Num_Subtask++;
        	}
        	//CPU���� �����ϴ� �ð��� �־���
        	for(int time=0;time<taskData[i].Time_Execute.size();time++){
        		SubTask[Num_Subtask] = new Task("CPU����", new SimpleTimePeriod(taskData[i].Time_Execute.get(time), taskData[i].Time_Execute.get(time)+1));
        		SubTask[Num_Subtask].setPercentComplete(1.0);
        		MainTask[i].addSubtask(SubTask[Num_Subtask]);
        		Num_Subtask++;
        	}
        	//Deadline �ʰ��� Ż���� �ð��� �־���
        	for(int time=0;time<taskData[i].Time_OverDeadline.size();time++){
        		SubTask[Num_Subtask] = new Task("CPU����", new SimpleTimePeriod(taskData[i].Time_OverDeadline.get(time)-1, taskData[i].Time_OverDeadline.get(time)));
        		SubTask[Num_Subtask].setPercentComplete(0.0);
        		MainTask[i].addSubtask(SubTask[Num_Subtask]);
        		Num_Subtask++;
        	}
        	
        	s1.add(MainTask[i]); 
        }

        
        
        final TaskSeriesCollection collection = new TaskSeriesCollection();
        collection.add(s1);
        

        return collection;
    }
}