import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Scrollbar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import java.awt.Point;
import java.util.Random;

public class CheckErrorInput extends JFrame{
	private JTextField test;
	JPanel panel = new JPanel(); //Panel
	JButton MainBtn = new JButton("New button");
	public CheckErrorInput(DefaultTableModel model, int Mode) {
		
		boolean isFindError=false;
		if(model.getRowCount()==0){
			setSize(400,100);
			setLocation(800,450);
			getContentPane().add(MainBtn);
			MainBtn.setText("�Էµ� Input�� �����ϴ�. �ٽ� �Է����ּ���");
			setVisible(true);
			MainBtn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					setVisible(false);
				}
			});
		}
		
		if(model.getRowCount()>150){
			setSize(600,100);
			setLocation(700,450);
			getContentPane().add(MainBtn);
			MainBtn.setText("�Էµ� task�� 150���� �ʰ��մϴ�. task ������ 150�� �Դϴ�.");
			setVisible(true);
			MainBtn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					setVisible(false);
				}
			});
		}
		
		else if(Mode==1)
			isFindError=RM(model);
		else if(Mode==2)
			isFindError=EDF(model);
		else if(Mode==3)
			isFindError=Priority(model);
		
		//if(!isFindError)
		//	System.exit();
		//setVisible(true);
	}
	
	
	
	public boolean RM(DefaultTableModel model){
		for(int i=0;i<model.getRowCount();i++){
			if((int)model.getValueAt(i, 4)==0){
				setSize(800,100);
				setLocation(550,450);
				getContentPane().add(MainBtn);
				MainBtn.setText("RM Mode�� �ֱ� task �����Դϴ�. ���ֱ� taks�� �����ϰų� Mode�� ���� �� �ٽ� �������ּ���.");
				setVisible(true);
				MainBtn.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0){
						setVisible(false);
					}
				});
				return false;
			}
		}
		
		RM RMScehduling = new RM(model);
		return true;
	}
	
	public boolean EDF(DefaultTableModel model){
		EDF EDFScheduling = new EDF(model);
		return true;
	}
	
	public boolean Priority(DefaultTableModel model){
		
		Priority PriorityScheduling = new Priority(model);
		return true;
	}
}