import java.util.Comparator;


public class ComparatorPeriodic  implements Comparator<task>{
	@Override
	public int compare(task o1, task o2) {
		// TODO Auto-generated method stub
		  if (o1.Periodic > o2.Periodic) {
		   return 1;
		  }
		  if (o1.Periodic == o2.Periodic) {
		   if (o1.Priority < o2.Priority) {
		    return 1;
		   }
		  }
		  return -1;
	}
}